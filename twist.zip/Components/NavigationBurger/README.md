# Navigation Burger

A simple burger navigation to be displayed on mobile and tablet viewport sizes. Needs to be used in conjuction with a desktop navigation component, or adjusted to show up on all viewport sizes.
