# Slider Images Centered

Drop images on the gallery field, order them by drag & drop and optionally add a caption per image. Crops images into a predefined ratio, centers the active image slide and crops the previous and next image.
