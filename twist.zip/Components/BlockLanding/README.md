# Block Landing

Simple formatted text with a full width background color to draw attention to the Call to Action (CTA) button. Linebreaks (br-tags) convert to spaces on mobile for individual text flow control on desktop.
