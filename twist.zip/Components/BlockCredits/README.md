# Block Credits

Add your social media platform links and they will show up as predefined svg icons. Optional formatted text above the icons.
