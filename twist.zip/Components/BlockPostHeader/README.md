# Block Post Header

Displays post title, meta information (including reading time), excerpt and featured image when added to a single post template.
