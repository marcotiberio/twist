# Navigation Main

A simple navigation to be displayed on desktop viewport sizes. Needs to be used in conjuction with a mobile navigation component, or adjusted to show up on all viewport sizes.
