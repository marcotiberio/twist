# Feature Google Analytics

If a Google Analytics ID is provided in Global Options, the tracking code will be added to all pages, except for logged in WordPress admins. Entering "debug" instead will log to the browser console only.
